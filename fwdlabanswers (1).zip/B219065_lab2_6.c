#include<stdio.h>

int main()
{
int a;
printf("Enter an integer");
scanf("%d",&a);
printf("The number as a character: %c\n",a);
printf("The number as a decimal: %d\n",a);
printf("The number as a float: %f\n",a);
return(0);
}
