#include<stdio.h>
main()
{
    printf("*");
    printf("\n**");
    printf("\n***");
    printf("\n****");g

}
