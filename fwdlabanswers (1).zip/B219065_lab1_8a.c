#include<stdio.h>
int main()
{
    int i;
    for(i=0;i<=35;i+=5)
    {
        printf("%d ",i);
    }
    return(0);
}
