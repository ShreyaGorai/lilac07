#include<stdio.h>
main()
{

    int a=1,b=10,c=100,d=1000,e=10000;
    printf("%d\t%d\t%d\t%d\t%d\t",a,b,c,d,e);
    printf("\n%f\t%f\t%f\t%f\t%f",a,b,c,d,e);
}
