#include<stdio.h>
main()
{
    int quantity=0;
    float unitprice=0.0;
    printf("enter the values");
    scanf("%d%f",&quantity,&unitprice);
    printf("QUANTITY: %d",quantity);
    printf("\nPRICE: %f",unitprice);


}
