#include<stdio.h>
int main()
{
    printf("ENTER TWO NUMBERS");
    int x,y;
    scanf("%d%d",&x,&y);
    int m=x*y;
    printf("THE NUMBERS ARE %d,%d and their product is %d",x,y,m);
    return 0;

}
