#include <stdio.h>
int main()
{
   float n,r;
   printf("Enter The Angle in Radians ");
   scanf("%f",&n);
   r=n*57.295;
   printf("The Angle in Degrees is %.3f", r);
   return(0);

}
